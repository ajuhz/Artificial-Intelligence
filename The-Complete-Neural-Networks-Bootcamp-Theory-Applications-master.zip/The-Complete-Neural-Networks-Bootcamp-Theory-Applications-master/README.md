Code Files for the Udemy Course: The Complete Neural Networks Bootcamp: Theory, Applications </br>
You may find the course [here](https://www.udemy.com/the-complete-neural-networks-bootcamp-theory-applications/)

![Capture](https://user-images.githubusercontent.com/30661597/59561984-1debea00-9059-11e9-8665-1d09d05652f6.PNG)

Note that the code for building a Chatbot using Transformers is included in a seperate repository [here](https://github.com/fawazsammani/chatbot-transformer)

